package ia;

public abstract class Player implements PlayerInterface{
    private int code;
    private boolean turn_played;
    
    Player(int code){
        this.code = code;
    }

    public int get_code() {
        return code;
    }
    
    public boolean isTurn_played() {
        return turn_played;
    }
    
    @Override
    public void play(Board b){
        
        int cell = get_play(b);
        if (cell!=-1)
            turn_played = b.mark(cell, code);
    }
    
    
    public static Player create_player(String type, int code){
        
        if ("human".equals(type)){
            return new HumanPlayer(code);
        }
        if ("bot".equals(type)){
            return new BotPlayer(code);
        }

        return null;
        
    }
   
}
