package ia;

public interface PlayerInterface {
    
    public void play(Board b);
    
    public int get_play(Board b);
}
