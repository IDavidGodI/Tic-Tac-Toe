package ia;

import java.util.ArrayList;

public class Board {
    private int[] state = new int[9];
    
    public Board(){
        init();
    }
    
    public static char code_symbol(int code){
        return code==0? '-' : code==1? 'O' : 'X';
    }
    
    public final void init(){
        for (int i=0;i<9;i++){
            state[i]=0;
        }
    }

    public int[] get_state() {
        return state;
    }
    
    public static void show(int[] state){
        for (int i=0; i<9;i++){
            char s = code_symbol(state[i]);

            System.out.print("| "+s+" |");

            if ((i+1)%3==0){
                System.out.print("\n");
            }
        }
    }
    
    public void show(){
        show(state);
    }
    public static boolean mark(int[] state, int cell, int code){
        
        boolean marked = state[cell]==0;
        if (marked){ 
            state[cell] = code;
        }
        return marked;
    }
    public boolean mark(int cell, int code){
        return mark(state, cell, code);
    }
    
    public static boolean is_winner(int[] state, int code){
        return (
            (state[0]==code && state[1]==code && state[2]==code) ||
            (state[3]==code && state[4]==code && state[5]==code) ||
            (state[6]==code && state[7]==code && state[8]==code) ||
            
            (state[0]==code && state[3]==code && state[6]==code) ||
            (state[1]==code && state[4]==code && state[7]==code) ||
            (state[2]==code && state[5]==code && state[8]==code) ||
                
            (state[0]==code && state[4]==code && state[8]==code) ||
            (state[6]==code && state[4]==code && state[2]==code)
        );
    }
    public boolean is_winner(int code){
        return is_winner(state, code);
    }
    
    public static boolean filled(int[] state){
        for (int c : state){
            if (c==0) return false;
        }
        return true;
    }
    public boolean filled(){
        return filled(state);
    }
    
    public static int get_spaces(int[] state){
        int spaces = 0;
        for (int c : state){
            if (c==0) spaces++;
        }
        return spaces;
    }

    public int get_spaces(){
        return get_spaces(state);
    }

    public static ArrayList<Integer> get_spaces_index(int[] state){
        ArrayList<Integer> spaces = new ArrayList<>();

        for (int i=0;i<state.length;i++){
            if (state[i]==0) spaces.add(i);
        }

        return spaces;
    }

}
