package ia;


import java.util.PriorityQueue;

public class BotPlayer extends Player {
    
    int other_code;
    PriorityQueue<Integer> moves_queue;

    public BotPlayer(int code) {
        super(code);
        moves_queue = new PriorityQueue<Integer>();
        // moves_queue.add(3);
        other_code = code==1? 2 : 1;
        enqueue_move(2);
    }
    
    public void enqueue_move(int move){
        moves_queue.add(move);
    }

    @Override
    public int get_play(Board b){
        
        Integer pendiente = moves_queue.poll();
        Integer[] play = {0,null};
        System.out.println(pendiente);
        if (pendiente!=null){
            play[1] = pendiente;
        }
        else{
            play = minimax(b.get_state(), true);
        
        }

        
        System.out.println("| Bot selected: "+(play[1]+1)+" with a "+play[0]+" score.");
        
        return play[1];
    }
    
    public Integer[] minimax(int[] state, boolean max){
            Integer[] value = {0,null};
            if (terminal(state)){
                value[0] = get_value(state)*(Board.get_spaces(state)+1);
                return value;
            }

            if (max) value[0] = -Integer.MAX_VALUE;
            else value[0] = Integer.MAX_VALUE;
            
            for (int c : Board.get_spaces_index(state)){
                int[] new_state = result(state, c, max? get_code() : other_code);
                Integer[] new_value = minimax(new_state, !max);
                new_value[1] = c;
                if (max){
                if (new_value[0]>value[0]){
                    value = new_value;
                }
                }else{
                if (new_value[0]<value[0]){
                    value=new_value;
                }
                }
            }
            return value;
    }
    
    private boolean terminal(int[] state){
        return (
                Board.is_winner(state, get_code()) ||
                Board.is_winner(state, other_code) ||
                Board.filled(state)
        );
    }
    
    private int get_value(int[] state){
            if (Board.is_winner(state, get_code())) return 1;
            if (Board.is_winner(state, other_code)) return -1;
            return 0;
    }
    
    
    
    private int[] result(int[] state, int move, int code){
        int[] new_state = new int[9];
        System.arraycopy(state, 0, new_state, 0, 9);
        new_state[move] = code;
        
        return new_state;
    }
}
