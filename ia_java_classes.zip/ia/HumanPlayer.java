package ia;

import java.util.Scanner;

public class HumanPlayer extends Player{

    Scanner sc;
    public HumanPlayer(int code) {
        super(code);
        sc = new Scanner(System.in);
    }
    
    public int get_play(Board b){
        
        int play;
        System.out.print("Elija una casilla (1-9): ");
        
        play = sc.nextInt();

        
        if (play>=1 && play<=9){
            return play-1;
        }
        
        return play;
    }
}
