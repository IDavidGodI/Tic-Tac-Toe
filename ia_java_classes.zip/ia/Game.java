package ia;

public class Game {
    
    static Player[] players = new Player[2];
    
    public static void main(String[] args){
        
        Board b = new Board();
        
        
        
        boolean running = true;
        
        int turn=0;
        set_players("human", "bot");
        
        b.show();
        while(running){
            
            Player p = players[turn];
            int code = p.get_code();
            char symbol = Board.code_symbol(code);
            System.out.println("Turno del jugador "+symbol);
            
            p.play(b);
            
            if (p.isTurn_played()){
                turn = switch_turn(turn); 
                System.out.println();
                if (b.is_winner(code)){
                    System.out.println("Gana el jugador " + symbol);
                    running = false;
                }else if (b.filled()){
                    System.out.println("Empate");
                    running = false;
                }
                
            }            
            b.show();
        }
        
    }
    
    static void set_players(String type_player_o, String type_player_x){
        
        players[0] = Player.create_player(type_player_o, 1);
        players[1] = Player.create_player(type_player_x, 2);
    }
    
    static int switch_turn(int turn){
        return turn==0? 1:0;
    }
}
